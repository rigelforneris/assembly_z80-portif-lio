wla-dx
======

WLA DX - Yet Another GB-Z80/Z80/6502/65C02/6510/65816/HUC6280/SPC-700 Multi Platform Cross Assembler Package

If you encounter a bug, please create a small project under the "bug_exhibition" directory in the source tree, and use the project to make the bug show up. This will speed up 
fixing the bug by a lot!
