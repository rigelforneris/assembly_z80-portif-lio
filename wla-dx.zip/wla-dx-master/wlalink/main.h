
void procedures_at_exit(void);
int allocate_rom(void);
int parse_flags(char **flags, int flagc);
int parse_and_set_libdir(char *c, int contains_flag);
