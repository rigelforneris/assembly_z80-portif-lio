
int check_file_types(void);
int check_headers(void);
