#define FAILED 0
#define SUCCEEDED 1

