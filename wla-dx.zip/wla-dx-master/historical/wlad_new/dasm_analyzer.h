
int dasm_analyzer(void);
