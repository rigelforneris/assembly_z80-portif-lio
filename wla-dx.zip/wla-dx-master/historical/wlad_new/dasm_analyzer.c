
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"
#include "dasm_analyzer.h"


extern unsigned char *in;
extern int arg_only_code, arg_strings, arg_address, arg_labels, arg_mode, arg_value, fs;



int dasm_analyzer(void) {


  return SUCCEEDED;
}
