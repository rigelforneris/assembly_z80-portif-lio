
int dasm_brutal(void);
int collect_labels_brutal(void);
