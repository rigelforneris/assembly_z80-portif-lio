
int add_a_new_label(int address, char *label);
int get_mnemonic_type(int m, int *o);
