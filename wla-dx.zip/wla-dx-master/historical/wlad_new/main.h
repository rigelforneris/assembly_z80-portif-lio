
int main(int argc, char *argv[]);
int output_header(char *name, int r);
int parse_flags(char *f);
int letter_check(char c);
int get_value(char *s, int *v);
