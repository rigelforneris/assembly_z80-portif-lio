
int get_mnemonic_status(int i);
